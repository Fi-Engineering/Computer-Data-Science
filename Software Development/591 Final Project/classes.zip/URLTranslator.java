package Alex;

public class URLTranslator {
	String ETF; //spy, qqq, dia
	
	public String convert(String etf, String command) {
		//returns the URL given the etf and the command
		//high, low, open, close
		String URL = null;
		return URL;
	}
}
