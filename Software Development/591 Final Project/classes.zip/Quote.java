package Alex;

public class Quote {
	String ETF;
	double high;
	double low;
	double openPrice;
	double closePrice;
	
	public Quote(String high, String low, String open, String close) { //csv or otherwise
		//initialize the class variables (open, close, etc.)
	}
}
