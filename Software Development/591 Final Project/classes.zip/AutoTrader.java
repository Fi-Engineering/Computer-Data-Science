package Alex;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

public class AutoTrader {
	static WebsiteDataReader data;
	static ArrayList<Quote> SPYquotes;
	static ArrayList<Quote> QQQquotes;
	static ArrayList<Quote> DIAquotes;
	static int refreshRate = 10; //in seconds
	
	public static void main(String[] args) {
		while (true) {
			try {
				TimeUnit.SECONDS.sleep(refreshRate);
			} catch (InterruptedException e) {
				
			}
			Quote SPY = data.getData("SPY");
			SPYquotes.add(SPY);
			Quote QQQ = data.getData("QQQ");
			QQQquotes.add(QQQ);
			Quote DIA = data.getData("DIA");
			DIAquotes.add(DIA);
		}
	}
}
