package Alex;

import java.net.*;
import java.io.*;

public class WebsiteDataReader {
	URLTranslator translator; // converts commands to the url necessary to retrieve the data from IEX Cloud
								// API

	public Quote getData(String ETF) {
		String highURL = translator.convert(ETF, "high");
		String lowURL = translator.convert(ETF, "low");
		String openURL = translator.convert(ETF, "open");
		String closeURL = translator.convert(ETF, "close");
		String highOutput = readConnection(highURL);
		String lowOutput = readConnection(lowURL);
		String openOutput = readConnection(openURL);
		String closeOutput = readConnection(closeURL);
		Quote quote = new Quote(highOutput, lowOutput, openOutput, closeOutput);
		return quote;
	}
	
	private String readConnection(String url) {
		try {
			URL iex = new URL(url);
			URLConnection yc;
			yc = iex.openConnection();
			BufferedReader in = new BufferedReader(new InputStreamReader(yc.getInputStream()));
			String inputLine;
			String output = "";
			while ((inputLine = in.readLine()) != null)
				output += inputLine;
			in.close();
			return output;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "";
	}
}
