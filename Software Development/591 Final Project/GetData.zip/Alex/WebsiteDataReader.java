package Alex;

import java.net.*;
import java.io.*;

public class WebsiteDataReader {
	URLTranslator translator = new URLTranslator();
	
	public Quote getData(String ETF) {
		translator.setSandbox(true); //remove later
		String URL = translator.convert(ETF);
		String output = readConnection(URL);
		Quote quote = new Quote(output);
		quote.setETF(ETF);
		return quote;
	}
	
	private String readConnection(String url) {
		try {
			URL iex = new URL(url);
			URLConnection yc;
			yc = iex.openConnection();
			BufferedReader in = new BufferedReader(new InputStreamReader(yc.getInputStream()));
			String inputLine;
			String output = "";
			while ((inputLine = in.readLine()) != null)
				output += inputLine;
			in.close();
			return output;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "";
	}
	
//	public static void main(String[] args) {
//		WebsiteDataReader data = new WebsiteDataReader();
//		Quote SPY = data.getData("SPY");
//		System.out.println(SPY.toString());
//	}
}
