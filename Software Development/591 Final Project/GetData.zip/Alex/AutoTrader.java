package Alex;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

public class AutoTrader {
	static WebsiteDataReader data = new WebsiteDataReader();
	static ArrayList<Quote> SPYquotes = new ArrayList<Quote>();
	static ArrayList<Quote> QQQquotes = new ArrayList<Quote>();
	static ArrayList<Quote> DIAquotes = new ArrayList<Quote>();
	static final int refreshRate = 1; //in seconds
	
	public static void main(String[] args) {
		while (true) {
			try {
				TimeUnit.SECONDS.sleep(refreshRate);
			} catch (InterruptedException e) {
				
			}
			Quote SPY = data.getData("SPY");
			SPYquotes.add(SPY);
			Quote QQQ = data.getData("QQQ");
			QQQquotes.add(QQQ);
			Quote DIA = data.getData("DIA");
			DIAquotes.add(DIA);
		}
	}
}
