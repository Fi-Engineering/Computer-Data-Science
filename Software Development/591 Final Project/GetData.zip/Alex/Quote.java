package Alex;

import java.util.Scanner;

public class Quote {
	String ETF;
	double high;
	double low;
	double open;
	double close;

	public Quote(String text) {
		Scanner textScan = new Scanner(text);
		textScan.useDelimiter(",");
		int i = 0;
		while (textScan.hasNext()) {
			if (textScan.hasNextDouble()) {
				switch (i) {
				case 0:
					high = textScan.nextDouble();
					i++;
					break;
				case 1:
					low = textScan.nextDouble();
					i++;
					break;
				case 2:
					open = textScan.nextDouble();
					i++;
					break;
				case 3:
					close = textScan.nextDouble();
					i++;
					break;
				}
			} else
				textScan.next();
		}
		textScan.close();
	}

	public String getETF() {
		return ETF;
	}

	public void setETF(String eTF) {
		ETF = eTF;
	}

	public double getHigh() {
		return high;
	}

	public void setHigh(double high) {
		this.high = high;
	}

	public double getLow() {
		return low;
	}

	public void setLow(double low) {
		this.low = low;
	}

	public double getOpen() {
		return open;
	}

	public void setOpen(double open) {
		this.open = open;
	}

	public double getClose() {
		return close;
	}

	public void setClose(double close) {
		this.close = close;
	}
	
	public String toString() {
		return "ETF: " + ETF + ", high: " + high + ", low: " + low + ", open: " + open + ", close: " + close;
	}
}
