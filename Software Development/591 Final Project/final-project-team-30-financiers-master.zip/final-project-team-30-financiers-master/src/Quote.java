//package GetETFData;

import java.util.Scanner;

public class Quote {
    String ETF;
    String csvText;
    double high;
    double low;
    double open;
    double close;
    double k;

    public Quote(String text) { // text is passed as the output from the url that gets the information
        // typically looks like this:
        // "high,low,open,close20.1,20.1,20.1,20.1"
        Scanner textScan = new Scanner(text);
        textScan.useDelimiter(",");
        textScan.next(); // skips the word high
        textScan.next(); // skips the word low
        textScan.next(); // skips the word open
        high = Double.parseDouble(textScan.next().substring(5)); // gets the number after "close"
        low = Double.parseDouble(textScan.next()); // gets the number after that
        open = Double.parseDouble(textScan.next()); // etc.
        close = Double.parseDouble(textScan.next());
        textScan.close();
    }

    public String getETF() {
        return ETF;
    }

    public void setETF(String eTF) {
        ETF = eTF;
        csvText = ETF + "," + high + "," + low + "," + open + "," + close + "\n";
    }

    public double getHigh() {
        return high;
    }

    public void setHigh(double high) {
        this.high = high;
    }

    public double getLow() {
        return low;
    }

    public void setLow(double low) {
        this.low = low;
    }

    public double getOpen() {
        return open;
    }

    public void setOpen(double open) {
        this.open = open;
    }

    public double getClose() {
        return close;
    }

    public void setClose(double close) {
        this.close = close;
    }

    public String toString() {
        return "ETF: " + ETF + ", high: " + high + ", low: " + low + ", open: " + open + ", close: " + close;
    }

    public void setK(double k) {
        this.k = k;
    }

    public double getK() {
        return k;
    }
}
