//package GetETFData;

public class URLTranslator {
    String base = "https://cloud.iexapis.com/stable/stock/"; // base url for retrieving stocks
    String ETF; // spy, qqq, dia
    String range = "/quote"; // latest quote
    String filter = "&filter=high,low,open,close"; // can pass isUSMarketOpen to see if that's the case
    String format = "&format=csv"; // csv format
    private String token = "?token=pk_7313575e87494da491b522361a906d15"; // public token

    String testBase = "https://sandbox.iexapis.com/stable/stock/";
    private String testToken = "?token=Tpk_c72352ab6cf9403db89a7a721b5434cc";
    boolean sandbox = false;

    public void setSandbox(boolean sandbox) {
        this.sandbox = sandbox;
    }

    public String convert(String etf) {
        String URL;
        // returns the URL given the etf
        // high, low, open, close
        URL = base + etf + range + token + filter + format;
        if (sandbox) URL = testBase + etf + range + testToken + filter + format;
        return URL;
    }

    public static void main(String[] args) {
        System.out.println(new URLTranslator().convert("SPY"));
    }
}
