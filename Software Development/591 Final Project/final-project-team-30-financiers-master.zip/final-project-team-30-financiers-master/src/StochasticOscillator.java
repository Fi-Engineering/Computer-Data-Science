//package Analysis;

/**
 * This class is the Stochastic Oscillator, which is a financial indicator
 *
 * @author Chris Payne
 *
 */
public abstract class StochasticOscillator {

    /**
     * Calculate the Stochastic Oscillator momentum indicator see the following URL
     * for more info: https://www.investopedia.com/terms/s/stochasticoscillator.asp
     *
     * @param h14
     * @param l14
     * @param close
     * @return
     */
    public static double calcStochasticOScillation(double h14, double l14, double close) {
        // class to calculate the Stochastic Oscillator indicator
        double numerator = close - l14;
        double denominator = h14 - l14;
        double k = (numerator / denominator) * 100;
        return k;
    }

}