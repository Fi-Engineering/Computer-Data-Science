//package Analysis;
//import org.testng.annotations.Test;
//
///**
// * JUnit test program to test the stochastic oscillation calculation
// * @author Chris Payne
// *
// */
//class StochasticOscillatorTest {
//
//    @Test
//    void testStochasticOscillator() {
//
//    }
//}
