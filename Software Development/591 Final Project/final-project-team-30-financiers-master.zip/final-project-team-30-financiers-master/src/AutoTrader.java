//package GetETFData;
//import Analysis.StochasticOscillator;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

public class AutoTrader {
    static WebsiteDataReader data = new WebsiteDataReader();
    static ArrayList<Quote> SPYquotes = new ArrayList<Quote>();
    static ArrayList<Quote> QQQquotes = new ArrayList<Quote>();
    static ArrayList<Quote> DIAquotes = new ArrayList<Quote>();
    static double SPYtolerance = 100.0; // minimum threshold required to initiate trade
    static double QQQtolerance = 75.0; // minimum threshold required to initiate trade
    static double DIAtolerance = 50.0; // minimum threshold required to initiate trade
    static final int refreshRate = 1; // in seconds

    public static void main(String[] args) {
        int run = 1;
        while (run-- != 0) {
            try {
                TimeUnit.SECONDS.sleep(refreshRate);
            } catch (InterruptedException e) {

            }
            Quote SPY = data.getData("SPY");
            SPYquotes.add(SPY);
            SPY.setK(StochasticOscillator.calcStochasticOScillation(SPY.getHigh(), SPY.getLow(), SPY.getClose()));
            System.out.println(StochasticOscillator.calcStochasticOScillation(SPY.getHigh(), SPY.getLow(), SPY.getClose()));
            System.out.println(decideTrade(SPY));
            Quote QQQ = data.getData("QQQ");
            QQQquotes.add(QQQ);
            QQQ.setK(StochasticOscillator.calcStochasticOScillation(QQQ.getHigh(), QQQ.getLow(), QQQ.getClose()));
            System.out.println(decideTrade(QQQ));
            Quote DIA = data.getData("DIA");
            DIAquotes.add(DIA);
            DIA.setK(StochasticOscillator.calcStochasticOScillation(DIA.getHigh(), DIA.getLow(), DIA.getClose()));
            System.out.println(decideTrade(DIA));
        }
        saveData();
    }

    public static boolean decideTrade(Quote quote) {
        double stochasticOscillator = quote.getK();
        double tolerance;
        switch (quote.getETF()) {
            case "SPY":
                tolerance = SPYtolerance;
                break;
            case "QQQ":
                tolerance = QQQtolerance;
                break;
            case "DIA":
                tolerance = DIAtolerance;
                break;
            default:
                return false;
        }

        return stochasticOscillator > tolerance;
    }

    // public static void saveData() {
    //     System.out.println("Outputting data to test.csv");
    //     try {
    //         FileWriter test = new FileWriter("test.csv");
    //         test.append("ETF,high,low,open,close\n");
    //         for (Quote SPYquote : SPYquotes) {
    //             test.append(SPYquote.csvText);
    //         }
    //         for (Quote DIAquote : DIAquotes) {
    //             test.append(DIAquote.csvText);
    //         }
    //         for (Quote QQQquote : QQQquotes) {
    //             test.append(QQQquote.csvText);
    //         }
    //         test.flush();
    //         test.close();
    //     } catch (IOException e) {
    //         // TODO Auto-generated catch block
    //         e.printStackTrace();
    //     }
    // }
}
