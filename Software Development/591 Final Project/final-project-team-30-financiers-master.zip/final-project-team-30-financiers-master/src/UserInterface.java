import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class UserInterface implements Runnable{

    //Instance Variables
    private JTextField searchTextField,t2,t3,t4,t5;
    private String[] myArray = {"Search ETFs", "Search Stocks", "Search Commodities", "Search Bonds"};
    private JComboBox newBox = new JComboBox(myArray);
    private JLabel ETF1 = new JLabel();
    private JLabel ETF2 = new JLabel();
    private JLabel ETF3 = new JLabel();

    @Override
    public void run() {

        //Layout Manager
        JFrame frame = new JFrame("Financiers Team 30");

        //This divides the frame into a grid layout for displaying information with different pannels
        JPanel outerPanel = new JPanel(new GridLayout(8,1));
        outerPanel.setBackground(Color.BLACK);
        JPanel innerTopPanel = new JPanel(new FlowLayout());
        innerTopPanel.setBackground(Color.BLACK);
        JPanel searchPanel = new JPanel(new FlowLayout());
        searchPanel.setBackground(Color.BLACK);

        //Create Components
        JButton refreshButton = new JButton("Refresh"); //Create a Button to refresh the data when the user wants
        JLabel myLabel = new JLabel("Filter Technical Options");
        myLabel.setForeground(Color.WHITE);

        JButton searchButton = new JButton("Search");
        JButton displayTradeData = new JButton("DisplayTrades");
        displayTradeData.setBackground(Color.RED);
        displayTradeData.setOpaque(true);
        displayTradeData.setBorderPainted(false);

        searchTextField=new JTextField("Search ETF");
        searchTextField.setBounds(50,100, 200,30);

        t2 =new JTextField("Search Results");
        t2.setBounds(50,150, 200,30);
        t2.setBackground(Color.GREEN);

        //Add the components together
        frame.add(outerPanel);
        outerPanel.add(innerTopPanel);
        outerPanel.add(searchPanel);
        innerTopPanel.add(refreshButton);
        innerTopPanel.add(myLabel);
        innerTopPanel.add(newBox);
        innerTopPanel.add(displayTradeData);
        searchPanel.add(searchTextField);
        searchPanel.add(searchButton);
        outerPanel.add(t2);
        outerPanel.add(ETF1);
        outerPanel.add(ETF2);
        outerPanel.add(ETF3);

        //ActionListeners
        searchButton.addActionListener(getSearchButtonAction());
        displayTradeData.addActionListener(displayTradeButtonAction());

        //Require pieces of code for swing
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setSize(800,500);
        frame.setVisible(true);
    }

    private ActionListener getSearchButtonAction() {
        return new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String etfASymbol = searchTextField.getText();
                WebsiteDataReader data = new WebsiteDataReader();
                Quote quote = data.getData(etfASymbol);
                t2.setText(quote.toString());
            }
        };
    }

    private ActionListener displayTradeButtonAction() {
        return new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                WebsiteDataReader data = new WebsiteDataReader();
                Quote SPY = data.getData("SPY");
                boolean tradeSPYResult = AutoTrader.decideTrade(SPY);
                Quote QQQ = data.getData("QQQ");
                boolean tradeQQQResult = AutoTrader.decideTrade(QQQ);
                Quote DIA = data.getData("DIA");
                boolean tradeDIAResult = AutoTrader.decideTrade(DIA);

                ETF1.setText(getTextForTradeResult(SPY, tradeSPYResult));
                ETF1.setForeground(tradeSPYResult ? Color.GREEN : Color.RED);

                ETF2.setText(getTextForTradeResult(QQQ, tradeQQQResult));
                ETF2.setForeground(tradeQQQResult ? Color.GREEN : Color.RED);

                ETF3.setText(getTextForTradeResult(DIA, tradeDIAResult));
                ETF3.setForeground(tradeDIAResult ? Color.GREEN : Color.RED);
            }
        };
    }

    private String getTextForTradeResult(Quote quote, boolean success) {
        String text = " | Trade with " + quote.getETF();
        String result =  success ? " was executed " : " was NOT executed ";
        String endText = "Based on Stochastic Indicator.";
        return quote.toString() + text + result + endText;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new UserInterface());
    }
}

