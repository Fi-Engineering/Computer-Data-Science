# MCIT 591 FINAL PROJECT
## GROUP 30 - Financiers
### Jhordan Figueroa, Alex Ilgenfritz, Chris Payne

# Purpose
This is the final project for the Fall 2019 offering of MCIT 591. This project pulls in data from the three largest exchange-traded funds (ETFs), the QQQ (Nasdaq), S&P 500, and the Dow Jones (DJIA). After the data is pulled in, technical analysis and fundamental finance algorithms are used to analyze the data and display them in a user-friendly interface. 